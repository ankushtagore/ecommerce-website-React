import React from 'react';


function Jewellery({ history }) {
    return (
      <div>
      <h1 style={{color:'red'}}>hello</h1>
      <h1> suidoidjsaoijsiojoihjoihiohoihiohjoihoih</h1>
      </div>
    )
}

export default Jewellery