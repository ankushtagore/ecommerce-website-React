import React from 'react';
import Directory from '../../../components/directory/Directory.component'
import { DesignOutfitContainer } from './designoutfit.styles'


export default function DesignerYourOutfit({ history }) {
    return (
      
        <DesignOutfitContainer>
            <Directory />
        </DesignOutfitContainer>
    )
}
