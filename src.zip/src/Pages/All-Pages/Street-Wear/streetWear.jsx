import React from 'react';


function StreetWear({ history }) {
    return (
      <div>
      <h1 style={{color:'red'}}>hello</h1>
      <h1> suidoidjsaoijsiojoihjoihiohoihiohjoihoih</h1>
      </div>
    )
}

export default StreetWear